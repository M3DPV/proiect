﻿namespace namssssss
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.five = new System.Windows.Forms.Button();
            this.indexpanel = new System.Windows.Forms.Panel();
            this.four = new System.Windows.Forms.Button();
            this.three = new System.Windows.Forms.Button();
            this.two = new System.Windows.Forms.Button();
            this.one = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.exit = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.contact1 = new namssssss.CONTACT();
            this.utilizari1 = new namssssss.Utilizari();
            this.proiecte1 = new namssssss.proiecte();
            this.contacte1 = new namssssss.Contacte();
            this.firstCustomControl = new namssssss.despre();
            this.contact2 = new namssssss.CONTACT();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.five);
            this.panel1.Controls.Add(this.indexpanel);
            this.panel1.Controls.Add(this.four);
            this.panel1.Controls.Add(this.three);
            this.panel1.Controls.Add(this.two);
            this.panel1.Controls.Add(this.one);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(267, 554);
            this.panel1.TabIndex = 0;
            // 
            // five
            // 
            this.five.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.five.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.five.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.five.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.five.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.five.Location = new System.Drawing.Point(72, 481);
            this.five.Margin = new System.Windows.Forms.Padding(4);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(123, 44);
            this.five.TabIndex = 8;
            this.five.Text = "Contact";
            this.five.UseVisualStyleBackColor = true;
            this.five.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // indexpanel
            // 
            this.indexpanel.BackColor = System.Drawing.Color.Maroon;
            this.indexpanel.Location = new System.Drawing.Point(0, 78);
            this.indexpanel.Margin = new System.Windows.Forms.Padding(4);
            this.indexpanel.Name = "indexpanel";
            this.indexpanel.Size = new System.Drawing.Size(13, 75);
            this.indexpanel.TabIndex = 7;
            // 
            // four
            // 
            this.four.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.four.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.four.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.four.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.four.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.four.Location = new System.Drawing.Point(0, 299);
            this.four.Margin = new System.Windows.Forms.Padding(4);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(267, 75);
            this.four.TabIndex = 5;
            this.four.Text = "PROIECTE";
            this.four.UseVisualStyleBackColor = true;
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // three
            // 
            this.three.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.three.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.three.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.three.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.three.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three.ForeColor = System.Drawing.Color.White;
            this.three.Location = new System.Drawing.Point(0, 228);
            this.three.Margin = new System.Windows.Forms.Padding(4);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(267, 75);
            this.three.TabIndex = 4;
            this.three.Text = "DOMENII";
            this.three.UseVisualStyleBackColor = true;
            this.three.Click += new System.EventHandler(this.button2_Click);
            // 
            // two
            // 
            this.two.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.two.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.two.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.two.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.two.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.two.Location = new System.Drawing.Point(0, 153);
            this.two.Margin = new System.Windows.Forms.Padding(0);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(267, 75);
            this.two.TabIndex = 3;
            this.two.Text = "DESPRE 3D";
            this.two.UseVisualStyleBackColor = true;
            this.two.Click += new System.EventHandler(this.button1_Click);
            // 
            // one
            // 
            this.one.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.one.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.one.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.one.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.one.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.one.Location = new System.Drawing.Point(0, 78);
            this.one.Margin = new System.Windows.Forms.Padding(4);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(267, 75);
            this.one.TabIndex = 2;
            this.one.Text = "ACASĂ";
            this.one.UseVisualStyleBackColor = true;
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.Controls.Add(this.exit);
            this.panel2.Location = new System.Drawing.Point(267, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(803, 28);
            this.panel2.TabIndex = 1;
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.Transparent;
            this.exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.exit.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.exit.FlatAppearance.BorderSize = 0;
            this.exit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.exit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.ForeColor = System.Drawing.Color.DeepPink;
            this.exit.Location = new System.Drawing.Point(776, 4);
            this.exit.Margin = new System.Windows.Forms.Padding(0);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(23, 23);
            this.exit.TabIndex = 9;
            this.exit.Text = "x";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // contact1
            // 
            this.contact1.BackColor = System.Drawing.Color.Orchid;
            this.contact1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contact1.Location = new System.Drawing.Point(266, 31);
            this.contact1.Margin = new System.Windows.Forms.Padding(5);
            this.contact1.Name = "contact1";
            this.contact1.Size = new System.Drawing.Size(800, 523);
            this.contact1.TabIndex = 7;
            // 
            // utilizari1
            // 
            this.utilizari1.Location = new System.Drawing.Point(267, 31);
            this.utilizari1.Margin = new System.Windows.Forms.Padding(5);
            this.utilizari1.Name = "utilizari1";
            this.utilizari1.Size = new System.Drawing.Size(800, 523);
            this.utilizari1.TabIndex = 6;
            // 
            // proiecte1
            // 
            this.proiecte1.Location = new System.Drawing.Point(267, 36);
            this.proiecte1.Margin = new System.Windows.Forms.Padding(5);
            this.proiecte1.Name = "proiecte1";
            this.proiecte1.Size = new System.Drawing.Size(800, 369);
            this.proiecte1.TabIndex = 4;
            // 
            // contacte1
            // 
            this.contacte1.Location = new System.Drawing.Point(267, 36);
            this.contacte1.Margin = new System.Windows.Forms.Padding(5);
            this.contacte1.Name = "contacte1";
            this.contacte1.Size = new System.Drawing.Size(800, 369);
            this.contacte1.TabIndex = 3;
            // 
            // firstCustomControl
            // 
            this.firstCustomControl.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.firstCustomControl.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("firstCustomControl.BackgroundImage")));
            this.firstCustomControl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.firstCustomControl.Location = new System.Drawing.Point(267, 36);
            this.firstCustomControl.Margin = new System.Windows.Forms.Padding(5);
            this.firstCustomControl.Name = "firstCustomControl";
            this.firstCustomControl.Size = new System.Drawing.Size(808, 364);
            this.firstCustomControl.TabIndex = 2;
            // 
            // contact2
            // 
            this.contact2.BackColor = System.Drawing.Color.Orchid;
            this.contact2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contact2.Location = new System.Drawing.Point(266, 22);
            this.contact2.Margin = new System.Windows.Forms.Padding(4);
            this.contact2.Name = "contact2";
            this.contact2.Size = new System.Drawing.Size(800, 462);
            this.contact2.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.contact2);
            this.Controls.Add(this.contact1);
            this.Controls.Add(this.utilizari1);
            this.Controls.Add(this.proiecte1);
            this.Controls.Add(this.contacte1);
            this.Controls.Add(this.firstCustomControl);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button three;
        private System.Windows.Forms.Button two;
        private System.Windows.Forms.Button one;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button four;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private despre firstCustomControl;
        private Contacte contacte1;
        private proiecte proiecte1;
        private Utilizari utilizari1;
        private System.Windows.Forms.Panel indexpanel;
        private System.Windows.Forms.Button five;
        private CONTACT contact1;
        private System.Windows.Forms.Button exit;
        private CONTACT contact2;
    }
}

